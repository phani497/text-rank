# Text summarization web application

[![Python](https://img.shields.io/badge/Python-3.8-3776AB.svg?style=flat&logo=python&logoColor=FFDB4D)](https://www.python.org)
[![Streamlit](https://img.shields.io/badge/Streamlit-app-FF4B4B.svg?style=flat)](https://www.streamlit.io)
[![Heroku](https://img.shields.io/badge/Heroku-deployed-430098.svg?style=flat&logo=heroku)](https://www.heroku.com)
[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

[**https://textrank-summarizer.herokuapp.com/**](https://textrank-summarizer.herokuapp.com/)

A simple web application that uses the [TextRank](https://github.com/summanlp/textrank) algorithm to summarize text.
The application is built with [Streamlit](https://www.streamlit.io) and deployed on Heroku using a GitHub action and Docker.

---

[![jhc github](https://img.shields.io/badge/GitHub-jhrcook-181717.svg?style=flat&logo=github)](https://github.com/jhrcook)
[![jhc twitter](https://img.shields.io/badge/Twitter-@JoshDoesA-00aced.svg?style=flat&logo=twitter)](https://twitter.com/JoshDoesa)
[![jhc website](https://img.shields.io/badge/Website-Joshua_Cook-5087B2.svg?style=flat&logo=telegram)](https://joshuacook.netlify.com)
